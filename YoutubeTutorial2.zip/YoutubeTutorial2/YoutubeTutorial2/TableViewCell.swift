//
//  TableViewCell.swift
//  YoutubeTutorial2
//
//  Created by aravind-pt2199 on 28/05/19.
//  Copyright © 2019 aravind-pt2199. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func loadData(dataSource: String) {
        self.titleLabel?.text = dataSource
    }
    
}
