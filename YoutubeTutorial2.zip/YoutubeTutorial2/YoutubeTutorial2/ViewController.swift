//
//  ViewController.swift
//  YoutubeTutorial2
//
//  Created by aravind-pt2199 on 28/05/19.
//  Copyright © 2019 aravind-pt2199. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var youtubeTableView: UITableView?
    
    var dataSource = ["vanila" , "strawberry" , "chacho" , "Lazy","vanila" , "strawberry" , "chacho" , "Lazy","vanila" , "strawberry" , "chacho" , "Lazy"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //First we need to create tableview in storyboard.
        
        //Now we create the tableview cell , we have to register our cell
        
        //Now we show title in cell
        
        self.setTableViewDelegates()
    }

    func setTableViewDelegates() {
        self.youtubeTableView?.dataSource = self
        self.youtubeTableView?.delegate = self
        
        self.youtubeTableView?.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "Cell")
        
        self.youtubeTableView?.separatorColor = .black
    }

}

extension ViewController: UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //we have to give total number of cells we needed
        return dataSource.count //I have added sample four data (static)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Here we have to return the tableview cell
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as? TableViewCell else {
            return UITableViewCell()
        }
        cell.loadData(dataSource: dataSource[indexPath.row])
        cell.selectionStyle = .none //coz we don want selection color changes
        
        cell.backgroundColor = .gray // I have set background color for cell
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(dataSource[indexPath.row]) // It will show the current selected cell datasource value
        
        dataSource.append("New Added")
        
        youtubeTableView?.beginUpdates()
        youtubeTableView?.insertRows(at: [IndexPath(row: dataSource.count - 1, section: 0)], with: .automatic)
        youtubeTableView?.endUpdates()
    }
    
}
